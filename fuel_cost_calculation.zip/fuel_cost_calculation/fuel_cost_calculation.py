print("fuel cost calculation")

cost_per_kilometer = int(input("please enter the your vehicle of cost per kilometer ($/km): "))
kilometers_traveled = int(input("please enter the kilometers traveled with your vehicle (km): "))

overall_cost = cost_per_kilometer * kilometers_traveled
print("the amount you have to pay: {} $".format(overall_cost))
