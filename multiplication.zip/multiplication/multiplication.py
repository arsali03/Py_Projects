print("please enter the 3 numbers you want  to multiply:")

number1 = int(input("first number: "))
number2 = int(input("second number: "))
number3 = int(input("third number: "))

total = number1 * number2 * number3

print("result of multiply: {}".format(total))