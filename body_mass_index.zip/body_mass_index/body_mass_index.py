print("body mass index calculator")

height = int(input("please enter the your height for body mass index (cm):"))
weight = int(input("please enter the your weight for body mass index (kg):"))

bmi = (weight / (height * height)) * 10000

print("your body mass index: {}".format(bmi))





