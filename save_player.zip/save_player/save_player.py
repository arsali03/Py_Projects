print("oyuncu kaydetme programı")

ad=input("oyuncunun adı:")
soyad=input("oyuncunun soyadı:")
takim=input("oyuncunun takımı:")

bilgiler=[ad,soyad,takim]

print("bilgiler kaydediliyor.....")

print("oyuncu adı: {}\noyuncu soyadı: {}\noyuncu takımı: {}\n".format(bilgiler[0],bilgiler[1],bilgiler[2]))
print("bilgiler kaydedildi.....")