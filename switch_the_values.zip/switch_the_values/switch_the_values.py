print("\nswitch the values\n")

first_value = int(input("please enter the first value you want to change:"))
second_value = int(input("please enter the second value you want to change:"))

print("first value entered: {}".format(first_value))
print("second value entered: {}".format(second_value))
print("values is changing.....")

switcher = 0
switcher = first_value
first_value = second_value
second_value = switcher

print("first value: {}".format(first_value))
print("second value: {}".format(second_value))

